def deg2kelvin(deg):

	return deg + 273

def kelvin2deg(kel):

	return kel -273

def resSeries(R1, R2):

	return R1 + R2

def resParallel(R1, R2):

	return (R1*R2)/(R1+R2)