# thermoToolKit
This is a set of tools programmed in python that allow the user to compute faster some interesting thermodynamic properties
